package com.cg.bookstore.beans;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class OrderInformation {
	
	@Id
	@SequenceGenerator(name="order_seq",sequenceName="order_seq", initialValue=10000, allocationSize=5000)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="order_seq")
	private int orderId;
	private String custName,streetAddress,city,country;
	private long custPhone,zipCode;
	

	int quantity;
	float subtotal, total;
	
	String status,payment;
	
	LocalDate orderDate;
	
	@ManyToOne
	private Customer customer;
	
	@OneToMany(mappedBy="order")
	private List<Book> book= new ArrayList<>();
	
	public OrderInformation() {
		// TODO Auto-generated constructor stub
	}

	public OrderInformation(int orderId, int quantity, float subtotal, float total, String status, String payment,
			LocalDate orderDate, Customer customer, List<Book> book) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.subtotal = subtotal;
		this.total = total;
		this.status = status;
		this.payment = payment;
		this.orderDate = orderDate;
		this.customer = customer;
		this.book = book;
	}
	
	public OrderInformation(int orderId, String custName, String streetAddress, String city, String country,
			long custPhone, long zipCode, int quantity, float subtotal, float total, String status, String payment,
			LocalDate orderDate, Customer customer, List<Book> book) {
		super();
		this.orderId = orderId;
		this.custName = custName;
		this.streetAddress = streetAddress;
		this.city = city;
		this.country = country;
		this.custPhone = custPhone;
		this.zipCode = zipCode;
		this.quantity = quantity;
		this.subtotal = subtotal;
		this.total = total;
		this.status = status;
		this.payment = payment;
		this.orderDate = orderDate;
		this.customer = customer;
		this.book = book;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(float subtotal) {
		this.subtotal = subtotal;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Book> getBook() {
		return book;
	}

	public void setBook(List<Book> book) {
		this.book = book;
	}
	

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public long getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(long custPhone) {
		this.custPhone = custPhone;
	}

	public long getZipCode() {
		return zipCode;
	}

	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public String toString() {
		return "OrderInformation [orderId=" + orderId + ", quantity=" + quantity + ", subtotal=" + subtotal + ", total="
				+ total + ", status=" + status + ", payment=" + payment + ", orderDate=" + orderDate + ", customer="
				+ customer + ", book=" + book + "]";
	}
	
	

}
