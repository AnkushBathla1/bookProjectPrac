package com.cg.bookstore.services;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	import com.cg.bookstore.beans.Customer;
	import com.cg.bookstore.beans.OrderInformation;
	import com.cg.bookstore.daoservices.CustomerDAOServices;
	import com.cg.bookstore.daoservices.OrderDaoServices;
	import com.cg.bookstore.exceptions.CustomerNotFound;
	import com.cg.bookstore.exceptions.OrderNotFoundException;

	@Component("orderInformationServices")
	public class OrderInformationServicesImpl implements IOrderInformationServices{

		@Autowired
		private OrderDaoServices orderDaoServices;
		@Autowired
		private CustomerDAOServices customerOrder;
		
		OrderInformation order;
		@Override
		public OrderInformation acceptOrder(OrderInformation order) throws OrderNotFoundException {
			
			return orderDaoServices.save(order);
		}

		@Override
		public void deleteOrder(int orderId, String emailId) throws OrderNotFoundException, CustomerNotFound {
			Customer customer=customerOrder.findById(emailId).orElseThrow(()-> new CustomerNotFound("Customer not regiestered with this email"));
			if(customer!=null)
			{		if(orderId==customer.getOrder().getOrderId())
				{order=orderDaoServices.findById(orderId).orElseThrow(()->new OrderNotFoundException());
			orderDaoServices.delete(order);
		} 
			} }

		@Override
		public OrderInformation editOrder(OrderInformation order) throws OrderNotFoundException {
			order= orderDaoServices.findById(order.getOrderId()).orElseThrow(()-> new OrderNotFoundException());
			return orderDaoServices.save(order);
		}

		@Override
		public OrderInformation showOrder(int orderId) throws OrderNotFoundException {
			// TODO Auto-generated method stub
			return orderDaoServices.findById(orderId).orElseThrow(()->new OrderNotFoundException("Order Not Found"));
		}

	}


