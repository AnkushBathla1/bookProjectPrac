package com.cg.bookstore.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bookstore.beans.Review;
import com.cg.bookstore.daoservices.ReviewDAOServices;
import com.cg.bookstore.exceptions.ReviewIdNotFoundException;

public class ReviewServiceImpl implements IReviewService{
    @Autowired
    ReviewDAOServices reviewDaoServices;
	@Override
	public Review addReview(Review review) {
		 reviewDaoServices.save(review);
		return review;
	}
/*
	@Override
	public void deleteReview(int reviewId) throws ReviewIdNotFoundException {
		Review review=reviewDaoServices.findById(reviewId).orElseThrow(()->new ReviewIdNotFoundException("Review Id is invalid"));
		
	}
*/
	@Override
	public void deleteReview(int reviewId) throws ReviewIdNotFoundException {
		// TODO Auto-generated method stub
		
	}
}
