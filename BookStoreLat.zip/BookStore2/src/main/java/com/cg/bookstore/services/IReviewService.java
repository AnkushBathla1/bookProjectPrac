package com.cg.bookstore.services;

import com.cg.bookstore.beans.Review;
import com.cg.bookstore.exceptions.ReviewIdNotFoundException;

public interface IReviewService {
public Review addReview(Review review);
public void deleteReview(int reviewId) throws ReviewIdNotFoundException;

}
