package com.cg.bookstore.services;

import com.cg.bookstore.beans.OrderInformation;
import com.cg.bookstore.exceptions.CustomerNotFound;
import com.cg.bookstore.exceptions.OrderNotFoundException;

public interface IOrderInformationServices {

	// BuyOrder, CancelOrder, OrderStatus, OrderPayment. 
		public OrderInformation acceptOrder(OrderInformation order) throws OrderNotFoundException;
		// placing order, quantity book name, address.
		public void deleteOrder(int orderId, String emailId) throws OrderNotFoundException,CustomerNotFound;
		// deleting previously made order yes no option.
		public OrderInformation editOrder(OrderInformation order) throws OrderNotFoundException;
		// editing order for changing address, payment method and status. ** Name and Order Should not be editable. 
		public OrderInformation showOrder(int orderId) throws OrderNotFoundException;
		//show details of order made.
	}
